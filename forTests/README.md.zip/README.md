# Сайдкар-контейнер со скриптом для pull'инга csv на сервисы-индексеры
Задача - https://detmir.atlassian.net/browse/OPS-5796  
  
