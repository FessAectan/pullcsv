[![coverage report](https://gitlab.detmir-infra.ru/detmir-ops/pull-csv/badges/main/coverage.svg)](https://gitlab.detmir-infra.ru/detmir-ops/pull-csv/-/commits/main)[![pipeline status](https://gitlab.detmir-infra.ru/detmir-ops/pull-csv/badges/main/pipeline.svg)](https://gitlab.detmir-infra.ru/detmir-ops/pull-csv/-/commits/main)[![Latest Release](https://gitlab.detmir-infra.ru/detmir-ops/pull-csv/-/badges/release.svg)](https://gitlab.detmir-infra.ru/detmir-ops/pull-csv/-/releases)

# Сервис для pull'инга csv на сервисы-индексеры
Задача - https://detmir.atlassian.net/browse/OPS-5796  
  
Сервис запускается в виде сайдкар-контейнера в поде с контейнером основного сервиса-индексатора.  
Принимает три переменные окружения:  
1. DOWNLOAD_FROM* - строка с полным (вместе с префиксом rsync://USER@SERVER) путём до файлов, которые нужно скачать с сервера.  
Если нужно передать несколько путей, просто разделяем их пробелом.  
Пример: `"rsync://SUBSYSTEMRS@cubic-sapint-01/pullcsv/prices/*_TODAY_*csv rsync://SUBSYSTEMRS@cubic-sapint-01/pullcsv/pim/*_TODAY_*csv"` 
2. DOWNLOAD_TO* - строка с полным путём до папки, куда нужно скачать файлы с сервера.  
Если нужно передать несколько путей, просто разделяем их пробелом.  
Пример: `"/backend-products/csv/in/ /backend-products/csv/in/"` 
3. RSYNC_PASSWORD - пароль на rsync-сервер  
*количество путей в DOWNLOAD_FROM должно соответствовать оному в DOWNLOAD_TO


В src/pullcsv.go функция, которая запускает несколько CronJobs (никак не звязан с kubernetes - просто использовал этот термин для простоты понимания). CronJobs двух типов:
1. Для скачивания файлов. Файлы pull'ятся из DOWNLOAD_FROM в DOWNLOAD_TO. Сколько передали в env-ах DOWNLOAD_FROM и DOWNLOAD_TO разделенных пробелами, столько CronJobs будет создано в виде go-рутин.
2. Для удаления старых файлов, которая удаляет все файлы старше 48 часов во всех DOWNLOAD_TO директориях. Тоже в виде go-рутин.